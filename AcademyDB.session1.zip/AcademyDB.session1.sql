-- -- 1. Створюємо таблицю чарівників
-- CREATE TABLE Wizards (
--     Id INT IDENTITY(1,1) PRIMARY KEY,
--     Name NVARCHAR(100) NOT NULL,
--     BloodStatus NVARCHAR(100) NOT NULL
-- );

-- -- 2. І тільки тепер накладаємо маскування на колонку!
-- ALTER TABLE Wizards
-- ALTER COLUMN BloodStatus NVARCHAR(100) 
--     MASKED WITH (FUNCTION = 'default()');

-- ALTER TABLE Wizards
-- ALTER COLUMN BloodStatus NVARCHAR(100) 
--     MASKED WITH (FUNCTION = 'default()');


-- ALTER TABLE Wizards
-- ALTER COLUMN BloodStatus NVARCHAR(100) 
--     MASKED WITH (FUNCTION = 'default()');

-- INSERT INTO Wizards (Name, BloodStatus) 
-- VALUES ('Harry Potter', 'Half-blood'), ('Draco Malfoy', 'Pure-blood');



-- SELECT Name, BloodStatus FROM Wizards;

-- EXECUTE AS USER = 'StudentUser';

-- SELECT Name, BloodStatus FROM Wizards;
-- REVERT;